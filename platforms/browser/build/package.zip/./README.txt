LANDING PAGE
============
    [ LOGO ]
    [ APP NAME ] 
    [ SMALL TAGLINE ] 
    GET STARTED BUTTON
    ------------------
        TERMS & CONDITIONS, EULA 
        ACCEPT TERMS & CONDITIONS BUTTON 
        --------------------------------
            MOBILE NUMBER INPUT 
            PASSWORD INPUT 
            CONFIRM PASSWORD INPUT 
            SELECT age BOX 
            CONTINUE BUTTON
            ---------------
                SEX [MAN, WOMAN]
                PUBLIC NAME INPUT
                INTERESTED IN [MEN, WOMEN, BOTH]
                CONTINUE BUTTON
                ---------------
                    MEMBERSHIP [GOLD, PREMIUM]
                    (MEMBERSHIP DETAILS)
                    CONTINUE BUTTON
                    ---------------
                        COUNTRY INPUT
                        CITY INPUT
                        SKILLS INPUT
                        ABOUT YOURSELF INPUT
                        FINISH BUTTON
                        -------------
                            DASHBOARD PAGE
                            ==============
                                LEFT PROFILE BUTTON
                                -------------------
                                PEOPLE | CONNECTIONS
                                
                                PEOPLE LIST
                                -----------
                                    PROFILE DETAILS
                                        SHOW LAST ACTIVE    
                                        PRIVATE CHAT [AVAILABLE / DISABLE]
                                        
                                    
                        
                    
RIGHT PANE
==========
    SEARCH 
    NEW REQUEST LIST

                    
LEFT PANE
=========
    PROFILE PIC
    NIC NAME
    MEMBERSHIP NAME
    
    TOTAL CONNECTIONS
    TOTAL LIKES
    PROFILE RANK
    
    
    SETTING LINK
    FEEDBACK LINK
    LICENSE LINK
    DELETE ACCOUNT
    
    
PRIVATE CHAT SCREEN
===================
    PRIVATE IMAGE GALLERY
    PRIVATE VIDEO CALL
    PRIVATE CHAT MESSENGER
    PRIVATE CALL
    RATING
    REVIEWS
    
    




<div data-page="started" class="page white no-swipeback">
  <!-- Scrollable page content-->
  <div class="page-content">
    
    
    <div class="content-block-title absolute-copyright" >
        <p> Copyright &copy; 2016, <a href="http://www.friendzzz.com" >FRIENDZZZ</a> </p> 
        <p style="text-transform: lowercase;"> All rights are reserved. </p>
    </div>
    
  </div>
</div>